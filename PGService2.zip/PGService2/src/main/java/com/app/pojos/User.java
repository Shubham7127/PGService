package com.app.pojos;

import javax.persistence.*;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Users")
public class User extends CommonEntity 
{   
		@Column
		private String email;
		@Column
		private String password;
		@Column
		private String fullName;
		@Column
		private long mobNo;
		@Column
		@Enumerated(EnumType.STRING) 
		private Gender gender;
		@Column
		private String collegeName;
	
}
